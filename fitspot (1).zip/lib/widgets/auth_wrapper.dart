import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:fitspot/firestore/firebase_provider.dart';
import 'package:fitspot/screens/welcome_screen.dart';
import 'package:fitspot/screens/home_page.dart';
import 'package:fitspot/services/local_data_service.dart';

class AuthWrapper extends StatefulWidget {
  const AuthWrapper({super.key});

  @override
  State<AuthWrapper> createState() => _AuthWrapperState();
}

class _AuthWrapperState extends State<AuthWrapper> {
  bool _localDataInitialized = false;

  @override
  void initState() {
    super.initState();
    _initLocalData();
  }

  Future<void> _initLocalData() async {
    await LocalDataService().init();
    setState(() {
      _localDataInitialized = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_localDataInitialized) {
      return const Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 16),
              Text('Inizializzazione...'),
            ],
          ),
        ),
      );
    }

    return Consumer<FirebaseProvider>(
      builder: (context, firebaseProvider, child) {
        // Check if user is in guest mode
        if (LocalDataService().isGuestMode) {
          return const HomePage();
        }

        if (firebaseProvider.isLoading) {
          return const Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Caricamento...'),
                ],
              ),
            ),
          );
        }

        if (firebaseProvider.isAuthenticated) {
          return const HomePage();
        }

        return const WelcomeScreen();
      },
    );
  }
}